
<?php echo $__env->make('layouts.sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<link rel="stylesheet" href="<?php echo e(asset('css/userpage/userpage.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('css/userpage/showmodal.css')); ?>">
<style>
    /* Custom spacing for report table columns */
    .custom-report-table th,
    .custom-report-table td {
        padding: 12px 20px;
        /* Increase horizontal and vertical spacing */
        white-space: nowrap;
        /* Prevent line breaks */
    }

    /* Optional: Make sure table is responsive and looks nice */
    .custom-report-table {
        font-size: 14px;
    }

    @media (max-width: 768px) {

        .custom-report-table th,
        .custom-report-table td {
            padding: 10px;
            font-size: 12px;
        }
    }
</style>
<style>
    .filter-section {
        display: flex;
        flex-wrap: wrap;
        align-items: center;
        gap: 15px;
        margin-bottom: 15px;
    }

    .filter-section .form-label {
        font-size: 0.85rem;
        font-weight: 500;
        color: #333;
    }

    .filter-section .form-control {
        min-width: 180px;
    }

    .download-buttons a {
        display: flex;
        align-items: center;
        gap: 6px;
        padding: 6px 12px;
        font-size: 0.9rem;
        border-radius: 6px;
    }

    .download-buttons {
        display: flex;
        gap: 10px;
        margin-top: 10px;
    }
</style>
<?php $__env->startSection('content'); ?>
<?php echo $__env->make('layouts.header', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

<div class="dashboard-content">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h2 class="section-title">
            <i class="fas fa-user-check me-2"></i>User Frontier Task Management Record
        </h2>
    </div>

    <div class="filter-section">

        <!-- User Filter Section -->
        <!-- User Dropdown Filter -->
        <div class="mb-3">
            <label for="user_filter" class="form-label fw-bold">Select User:</label>
            <select id="user_filter" class="form-select w-auto" onchange="redirectToUser(this)">
                <!-- All Users Option -->
                <option value="<?php echo e(route('user.frontier')); ?>" <?php echo e(!isset($user) ? 'selected' : ''); ?>>
                    All Users
                </option>
                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $u): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e(route('frontier.show', $u->id)); ?>" <?php echo e(isset($user) && $user->id == $u->id ? 'selected'
                    : ''); ?>>
                    <?php echo e($u->name); ?>

                </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>


        <script>
            function redirectToUser(select) {
        const url = select.value;
        if (url) window.location.href = url;
    }
        </script>


        <form action="<?php echo e(route('user.frontier')); ?>" method="GET" class="d-flex gap-3 align-items-end flex-wrap">
            <div>
                <label for="start_date" class="form-label mb-0 small">Start Date</label>
                <input type="date" id="start_date" name="start_date" value="<?php echo e(request('start_date')); ?>"
                    class="form-control form-control-sm">
            </div>
            <div>
                <label for="end_date" class="form-label mb-0 small">End Date</label>
                <input type="date" id="end_date" name="end_date" value="<?php echo e(request('end_date')); ?>"
                    class="form-control form-control-sm">
            </div>
            <div>
                <button type="submit" class="btn btn-sm btn-primary mt-2">
                    🔍 Search
                </button>
            </div>
            <div>
                <a href="<?php echo e(route('user.frontier')); ?>" class="btn btn-sm btn-secondary mt-2">Reset Date</a>
            </div>
        </form>


        <!-- Download Buttons -->
        <!-- Download Dropdown -->
        <div class="dropdown">
            <button class="btn btn-primary dropdown-toggle" type="button" id="downloadDropdown"
                data-bs-toggle="dropdown" aria-expanded="false">
                <i class="fas fa-download"></i> Download Records
            </button>

            <ul class="dropdown-menu" aria-labelledby="downloadDropdown">
                <li>
                    <a class="dropdown-item"
                        href="<?php echo e(route('adminfrontier.export.excel', array_merge(request()->all(), ['user_id' => isset($user) ? $user->id : null]))); ?>">
                        <i class="fas fa-file-excel text-success"></i> Excel File
                    </a>
                </li>
                <li>
                    <a class="dropdown-item"
                        href="<?php echo e(route('adminfrontier.export.csv', array_merge(request()->all(), ['user_id' => isset($user) ? $user->id : null]))); ?>">
                        <i class="fas fa-file-csv text-secondary"></i> CSV File
                    </a>
                </li>
                <li>
                    <a class="dropdown-item"
                        href="<?php echo e(route('adminfrontier.export.pdf', array_merge(request()->all(), ['user_id' => isset($user) ? $user->id : null]))); ?>">
                        <i class="fas fa-file-pdf text-danger"></i> PDF File
                    </a>
                </li>
            </ul>
        </div>
    </div>




    <div class="table-responsive">
        <table class="table table-striped table-bordered custom-report-table">
            <thead class="table-primary">
                <tr>
                    <th>ID</th>
                    <th>Date</th>
                    <th>First Name</th>
                    <th>Last Name</th>
                    <th>Corp ID</th>
                    <th>Address</th>
                    <th>Billing TN</th>
                    <th>Order Number</th>
                    <th>Install T.T. Soc TTC</th>
                    <th>ONT NTD</th>
                    <th>Comp/Refer</th>
                    <th>Billing Code</th>
                    <th>Qty</th>
                    <th>Description</th>
                    <th>Rate</th>
                    <th>Total Billed</th>
                    <th>Aerial Buried</th>
                    <th>Fiber</th>
                    <th>Closeout Notes</th>
                    <th>In</th>
                    <th>Out</th>
                    <th>Hours</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $frontiers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($loop->iteration); ?></td>
                    <td><?php echo e($data->created_at->format('m/d/Y')); ?></td>
                    <td><?php echo e($data->user->name ?? 'N/A'); ?></td>
                    <td><?php echo e($data->user->last_name ?? 'N/A'); ?></td>
                    <td><?php echo e($data->corp_id); ?></td>
                    <td><?php echo e($data->address); ?></td>
                    <td><?php echo e($data->billing_TN); ?></td>
                    <td><?php echo e($data->order_number); ?></td>
                    <td><?php echo e($data->install_T_T_Soc_TTC); ?></td>
                    <td><?php echo e($data->ont_Ntd); ?></td>
                    <td><?php echo e($data->comp_or_refer); ?></td>
                    <td><?php echo e($data->billing_code); ?></td>
                    <td><?php echo e($data->qty); ?></td>
                    <td><?php echo e($data->description); ?></td>
                    <td><?php echo e($data->rate); ?></td>
                    <td><?php echo e($data->total_billed); ?></td>
                    <td><?php echo e($data->aerial_buried); ?></td>
                    <td><?php echo e($data->fiber); ?></td>
                    <td><?php echo e($data->closeout_notes); ?></td>
                    <td><?php echo e($data->in); ?></td>
                    <td><?php echo e($data->out); ?></td>
                    <td><?php echo e($data->hours); ?></td>
                    <td>
                        <div class="d-flex align-items-center gap-2">
                            <a href="<?php echo e(route('admin.frontier.edit',$data->id)); ?>" class="btn btn-sm btn-warning">Edit</a>
                            <form action="<?php echo e(route('admin.frontier.destroy',$data->id)); ?>" method="POST" class="m-0">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button class="btn btn-sm btn-danger">Delete</button>
                            </form>
                        </div>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
        <div class="pagination justify-content-center mt-3">
            <?php echo e($frontiers->links()); ?>

        </div>
    </div>
</div>

<?php if(session('success')): ?>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script>
    Swal.fire({
        icon: 'success',
        title: 'Success!',
        text: '<?php echo e(session('success')); ?>',
        timer: 3000,
        showConfirmButton: false
    });
</script>
<?php endif; ?>

<?php if(session('success')): ?>
<script>
    Swal.fire({
        icon: 'success',
        title: 'Success!',
        text: '<?php echo e(session('success')); ?>',
        timer: 3000,
        showConfirmButton: false
    });
</script>
<?php endif; ?>


<script>
    function showSection(sectionId) {
        document.getElementById('form-section').style.display = 'none';
        document.getElementById('report-section').style.display = 'none';
        document.getElementById(sectionId).style.display = 'block';
    }

    // Wait for DOM to be ready
    document.addEventListener('DOMContentLoaded', function () {
        <?php if(request()->has('page') || request()->has('start_date') || request()->has('end_date')): ?>
            showSection('report-section');
        <?php else: ?>
            showSection('form-section');
        <?php endif; ?>
    });
</script>

<script>
    function calculateHours() {
        const inTime = document.getElementById('in').value;
        const outTime = document.getElementById('out').value;

        if (inTime && outTime) {
            const [inHours, inMinutes] = inTime.split(':').map(Number);
            const [outHours, outMinutes] = outTime.split(':').map(Number);

            const inDate = new Date(0, 0, 0, inHours, inMinutes);
            const outDate = new Date(0, 0, 0, outHours, outMinutes);

            let diff = (outDate - inDate) / (1000 * 60 * 60); // in hours

            // Handle next day
            if (diff < 0) diff += 24;

            document.getElementById('hours').value = diff.toFixed(2);
        }
    }
    document.getElementById('in').addEventListener('change', calculateHours);
    document.getElementById('out').addEventListener('change', calculateHours);
</script>

<?php if(session('success')): ?>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script>
    Swal.fire({
        icon: 'success',
        title: 'Success!',
        text: '<?php echo e(session('success')); ?>',
        timer: 3000,
        showConfirmButton: false
    });
</script>
<?php endif; ?>

<?php if(session('success')): ?>
<script>
    Swal.fire({
        icon: 'success',
        title: 'Success!',
        text: '<?php echo e(session('success')); ?>',
        timer: 3000,
        showConfirmButton: false
    });
</script>
<?php endif; ?>



<?php if(session('message')): ?>
<script>
    Swal.fire({
            icon: 'success',
            title: 'Success',
            text: '<?php echo e(session('message')); ?>',
            confirmButtonColor: '#3085d6'
        });
</script>
<?php endif; ?>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\About Laravel\Task_Management\resources\views/admin_sidebar/frontier_user_records.blade.php ENDPATH**/ ?>