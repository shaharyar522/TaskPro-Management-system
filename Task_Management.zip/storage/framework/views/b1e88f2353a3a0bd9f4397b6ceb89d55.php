<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <title>User CCI PDF</title>
    <style>
        @page {
            margin: 20px;
        }

        body {
            font-family: sans-serif;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            font-size: 9px;
            table-layout: fixed;
            word-wrap: break-word;
        }

        th,
        td {
            border: 1px solid #999;
            padding: 4px;
            text-align: left;
        }

        th {
            background-color: #eee;
        }
    </style>
</head>

<body>
    <h2>User CCI Report</h2>
    <table>
        <thead>
            <tr>
                <th style="width: 40px;">ID</th>
                <th style="width: 150px;">Address</th>
                <th style="width: 80px;">Phone</th>
                <th style="width: 100px;">Master Order</th>
                <th style="width: 150px;">Job Notes</th>
                <th style="width: 100px;">Work Type</th>
                <th style="width: 60px;">Unit</th>
                <th style="width: 40px;">Qty</th>
                <th style="width: 60px;">W2</th>
                <th style="width: 40px;">In</th>
                <th style="width: 40px;">Out</th>
                <th style="width: 40px;">Hours</th>
                <th style="width: 80px;">Created At</th>
                <th style="width: 80px;">Updated At</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $admincci; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($loop->iteration); ?></td>
                <td><?php echo e($data->address); ?></td>
                <td><?php echo e($data->phone); ?></td>
                <td><?php echo e($data->master_order); ?></td>
                <td><?php echo e($data->job_notes); ?></td>
                <td><?php echo e($data->work_type); ?></td>
                <td><?php echo e($data->unit); ?></td>
                <td><?php echo e($data->qty); ?></td>
                <td><?php echo e($data->w2); ?></td>
                <td><?php echo e($data->in); ?></td>
                <td><?php echo e($data->out); ?></td>
                <td><?php echo e($data->hours); ?></td>
                <td><?php echo e($data->created_at); ?></td>
                <td><?php echo e($data->updated_at); ?></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</body>

</html>
<?php /**PATH D:\About Laravel\Task_Management\resources\views/admin_sidebar/pdf/admin_cci_pdf.blade.php ENDPATH**/ ?>