
<?php echo $__env->make('layouts.sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<link rel="stylesheet" href="<?php echo e(asset('css/userpage/userpage.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('css/userpage/showmodal.css')); ?>">

<?php $__env->startSection('content'); ?>
<?php echo $__env->make('layouts.header', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>


<div class="dashboard-content">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h2 class="section-title">
            <i class="fas fa-user-check me-2"></i>User CCI Task Management
        </h2>
    </div>

    <div class="table-responsive">
        <table class="table user-approval-table" id="pending-users-table">
            <thead>
                <tr>
                    <th class="id-col">ID</th>
                    <th class="name-col">First Name</th>
                    <th class="name-col">Last Name</th>
                    <th class="copy-col">Copy ID</th>
                    <th class="project-col">Project Name</th>
                    <th class="date-col">Registration Date</th>
                    <th class="email-col">Email</th>
                    <th class="action-col">Actions</th>
                </tr> 
            </thead>
            <tbody>
                <?php $__currentLoopData = $CCI; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr id="user-row-<?php echo e($user->id); ?>">
                    <td class="id-col"><?php echo e($user->id); ?></td>
                    <td class="name-col"><span><?php echo e($user->name); ?></span></td>
                    <td class="name-col"><?php echo e($user->last_name); ?></td>
                    <td class="copy-col"><?php echo e($user->copy_id); ?></td>
                    <td class="project-col"><?php echo e($user->project_name); ?></td>
                    <td class="date-col"><?php echo e($user->created_at->format('d M Y')); ?></td>
                    <td class="email-col"><?php echo e($user->email); ?></td>
                    <td class="status-col">
                        <a href="<?php echo e(route('cci.show',$user->id)); ?>"
                            class="btn btn-sm btn-outline-primary d-inline-flex align-items-center gap-1 shadow-sm rounded-pill px-3 py-1">
                            <i class="fas fa-eye"></i> View Entries
                        </a>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\About Laravel\Task_Management\resources\views/admin_sidebar/cci_user.blade.php ENDPATH**/ ?>