<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <title>User Frontier PDF</title>
    <style>
        @page {
            margin: 20px;
        }

        body {
            font-family: sans-serif;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            font-size: 9px;
            table-layout: fixed;
            word-wrap: break-word;
        }

        th,
        td {
            border: 1px solid #999;
            padding: 4px;
            text-align: left;
        }

        th {
            background-color: #eee;
        }
    </style>
</head>

<body>
    <h2>User Frontier Report</h2>
    <table>
        <thead>
            <tr>
                <th style="width: 40px;">S.No</th>
                <th style="width: 80px;">Date</th>
                <th style="width: 100px;">First Name</th>
                <th style="width: 100px;">Last Name</th>
                <th style="width: 80px;">Corp ID</th>
                <th style="width: 150px;">Address</th>
                <th style="width: 80px;">Billing TN</th>
                <th style="width: 80px;">Order Number</th>
                <th style="width: 100px;">Install T.T. Soc TTC</th>
                <th style="width: 80px;">ONT NTD</th>
                <th style="width: 80px;">Comp/Refer</th>
                <th style="width: 80px;">Billing Code</th>
                <th style="width: 40px;">Qty</th>
                <th style="width: 200px;">Description</th>
                <th style="width: 60px;">Rate</th>
                <th style="width: 80px;">Total Billed</th>
                <th style="width: 60px;">Aerial Buried</th>
                <th style="width: 60px;">Fiber</th>
                <th style="width: 200px;">Closeout Notes</th>
                <th style="width: 40px;">In</th>
                <th style="width: 40px;">Out</th>
                <th style="width: 40px;">Hours</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $adminfrontire; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($loop->iteration); ?></td>
                <td><?php echo e($data->created_at ? $data->created_at->format('m/d/Y') : ''); ?></td>
                <td><?php echo e($data->user->name ?? 'N/A'); ?></td>
                <td><?php echo e($data->user->last_name ?? 'N/A'); ?></td>
                <td><?php echo e($data->corp_id); ?></td>
                <td><?php echo e($data->address); ?></td>
                <td><?php echo e($data->billing_TN); ?></td>
                <td><?php echo e($data->order_number); ?></td>
                <td><?php echo e($data->install_T_T_Soc_TTC); ?></td>
                <td><?php echo e($data->ont_Ntd); ?></td>
                <td><?php echo e($data->comp_or_refer); ?></td>
                <td><?php echo e($data->billing_code); ?></td>
                <td><?php echo e($data->qty); ?></td>
                <td><?php echo e($data->description); ?></td>
                <td><?php echo e($data->rate); ?></td>
                <td><?php echo e($data->total_billed); ?></td>
                <td><?php echo e($data->aerial_buried); ?></td>
                <td><?php echo e($data->fiber); ?></td>
                <td><?php echo e($data->closeout_notes); ?></td>
                <td><?php echo e($data->in); ?></td>
                <td><?php echo e($data->out); ?></td>
                <td><?php echo e($data->hours); ?></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</body>
</html>
<?php /**PATH D:\About Laravel\Task_Management\resources\views/admin_sidebar/pdf/admin_frontier_pdf.blade.php ENDPATH**/ ?>