<?php echo $__env->make('layouts.sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php $__env->startSection('content'); ?>
<!-- Header -->
<?php echo $__env->make('layouts.header', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<link rel="stylesheet" href="<?php echo e(asset('css/dashbodfront.css')); ?>">

<!-- Dashboard Content -->
<div class="dashboard-container">
    <!-- Welcome Card -->
    <div class="welcome-card">
        <div class="welcome-content">
            <div class="welcome-header">
                <h1 class="welcome-title">Task Management Dashboard</h1>
                <p class="welcome-text">Here's what's happening with your tasks today</p>
            </div>

            <div class="welcome-stats">


                <div class="stat-card">
                    <div class="stat-icon">
                        <i class="fas fa-clock"></i>
                    </div>
                    <div class="stat-info">
                        <span class="menu-badge bg-warning"><?php echo e($pendingCount ?? 0); ?></span>
                        <span class="stat-label">Pending User</span>
                    </div>
                </div>

                <div class="stat-card">

                    <div class="stat-icon">
                        <i class="fas fa-check-circle"></i>
                    </div>
                    <div class="stat-info">
                        <span class="menu-badge bg-success"><?php echo e($approvedCount ?? 0); ?></span>
                        <span class="stat-label">Approved User</span>
                    </div>
                </div>

                <div class="stat-card">
                    <div class="stat-icon">
                        <i class="fas fa-exclamation-triangle"></i>
                    </div>
                    <div class="stat-info">
                        <span class="menu-badge bg-danger"><?php echo e($blockedCount ?? 0); ?></span>
                        <span class="stat-label">blocked User</span>
                    </div>
                </div>
            </div>
        </div>

        <div class="welcome-illustration">
            <img src="https://illustrations.popsy.co/amber/digital-nomad.svg" alt="Task Management Illustration">
        </div>
    </div>


</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\About Laravel\Task_Management\resources\views/dashboard.blade.php ENDPATH**/ ?>