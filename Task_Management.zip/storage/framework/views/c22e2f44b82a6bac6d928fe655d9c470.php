<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Email</title>
</head>
<body>
    <h1><?php echo e($msg); ?></h1>
</body>
</html>
<?php /**PATH D:\About Laravel\Task_Management\resources\views/email/excelemail.blade.php ENDPATH**/ ?>