
<?php echo $__env->make('layouts.sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<link rel="stylesheet" href="<?php echo e(asset('css/userpage/userpage.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('css/userpage/showmodal.css')); ?>">
<style>
    /* Custom spacing for report table columns */
    .custom-report-table th,
    .custom-report-table td {
        padding: 12px 20px;
        /* Increase horizontal and vertical spacing */
        white-space: nowrap;
        /* Prevent line breaks */
    }

    /* Optional: Make sure table is responsive and looks nice */
    .custom-report-table {
        font-size: 14px;
    }

    @media (max-width: 768px) {

        .custom-report-table th,
        .custom-report-table td {
            padding: 10px;
            font-size: 12px;
        }
    }
</style>
<style>
    .filter-section {
        display: flex;
        flex-wrap: wrap;
        align-items: center;
        gap: 15px;
        margin-bottom: 15px;
    }

    .filter-section .form-label {
        font-size: 0.85rem;
        font-weight: 500;
        color: #333;
    }

    .filter-section .form-control {
        min-width: 180px;
    }

    .download-buttons a {
        display: flex;
        align-items: center;
        gap: 6px;
        padding: 6px 12px;
        font-size: 0.9rem;
        border-radius: 6px;
    }

    .download-buttons {
        display: flex;
        gap: 10px;
        margin-top: 10px;
    }
</style>
<?php $__env->startSection('content'); ?>
<?php echo $__env->make('layouts.header', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

<div class="dashboard-content">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h2 class="section-title">
            <i class="fas fa-user-check me-2"></i>User CCI Task Management Record
        </h2>
    </div>

    <div class="filter-section">
        
        <form action="" method="GET" class="d-flex gap-3 align-items-end flex-wrap">
            <div>
                <label for="start_date" class="form-label mb-0 small">Start Date</label>
                <input type="date" id="start_date" name="start_date" value="<?php echo e(request('start_date')); ?>"
                    class="form-control form-control-sm">
            </div>
            <div>
                <label for="end_date" class="form-label mb-0 small">End Date</label>
                <input type="date" id="end_date" name="end_date" value="<?php echo e(request('end_date')); ?>"
                    class="form-control form-control-sm">
            </div>
            <div>
                <button type="submit" class="btn btn-sm btn-primary mt-2">
                    🔍 Search
                </button>
            </div>
            <div>
                <a href="" class="btn btn-sm btn-secondary mt-2">Reset Date</a>
            </div>
        </form>

        <!-- Download Buttons -->
        <div class="download-buttons">
            <a href="<?php echo e(route('admincci.export.excel')); ?>" class="btn btn-success">
                <i class="fas fa-file-excel"></i>📄 Download Excel File
            </a>

            <a href="<?php echo e(route('admincci.export.csv')); ?>" class="btn btn-secondary">
                <i class="fas fa-file-csv"></i> 📄 Download CSV File
            </a>

            <a href="<?php echo e(route('admincci.export.pdf')); ?>" class="btn btn-danger">
                <i class="fas fa-file-pdf"></i> 📄 Download PDF File
            </a>
        </div>
    </div>


    <div class="table-responsive">
        <table class="table table-striped table-bordered custom-report-table">
            <thead class="table-primary">
                <tr>
                    <th>ID</th>
                    <th>Address</th>
                    <th>Phone</th>
                    <th>Master Order</th>
                    <th>Job Notes</th>
                    <th>Work Type</th>
                    <th>Unit</th>
                    <th>Qty</th>
                    <th>W2</th>
                    <th>In</th>
                    <th>Out</th>
                    <th>Hours</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $CCI; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($loop->iteration); ?></td>
                    <td><?php echo e($data->address); ?></td>
                    <td><?php echo e($data->phone); ?></td>
                    <td><?php echo e($data->master_order); ?></td>
                    <td><?php echo e($data->job_notes); ?></td>
                    <td><?php echo e($data->work_type); ?></td>
                    <td><?php echo e($data->unit); ?></td>
                    <td><?php echo e($data->qty); ?></td>
                    <td><?php echo e($data->w2); ?></td>
                    <td><?php echo e($data->in); ?></td>
                    <td><?php echo e($data->out); ?></td>
                    <td><?php echo e($data->hours); ?></td>
                    <td>
                        <!-- Edit button -->
                        <a href="<?php echo e(route('admin.cci.edit',$data->id)); ?>" class="btn btn-sm btn-warning">
                            Edit
                        </a>
                        <!-- Delete form -->
                        <form action="<?php echo e(route('admin.cci.destroy',$data->id)); ?>" method="POST" style="display:inline-block;">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button class="btn btn-sm btn-danger">Delete</button>
                        </form>

                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
         <div class="pagination justify-content-center mt-3">
                <?php echo e($CCI->links()); ?>

            </div>
    </div>
</div>

<?php if(session('success')): ?>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script>
    Swal.fire({
        icon: 'success',
        title: 'Success!',
        text: '<?php echo e(session('success')); ?>',
        timer: 3000,
        showConfirmButton: false
    });
</script>
<?php endif; ?>

<?php if(session('success')): ?>
<script>
    Swal.fire({
        icon: 'success',
        title: 'Success!',
        text: '<?php echo e(session('success')); ?>',
        timer: 3000,
        showConfirmButton: false
    });
</script>
<?php endif; ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\About Laravel\Task_Management\resources\views/admin_sidebar/cci_user_records.blade.php ENDPATH**/ ?>